local pedModels = Config.pedModels

RegisterCommand("spawnpeds", function(source, args, rawCommand)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    -- Parse the number of peds and radius from the command arguments
    local pedCount = tonumber(args[1])
    local spawnRadius = tonumber(args[2])
    if not pedCount or pedCount <= 0 then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Error", "Please specify a valid number of peds to spawn."}
        })
        return
    end

    if not spawnRadius or spawnRadius <= 0 then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"Error", "Please specify a valid spawn radius."}
        })
        return
    end

    for i = 1, pedCount do
        -- Select a random ped model
        local pedModel = pedModels[math.random(#pedModels)]

        -- Load the ped model
        RequestModel(pedModel)
        while not HasModelLoaded(pedModel) do
            Wait(0)
        end

        -- Generate random coordinates within the radius
        local offsetX = math.random(-spawnRadius, spawnRadius)
        local offsetY = math.random(-spawnRadius, spawnRadius)
        local spawnX = playerCoords.x + offsetX
        local spawnY = playerCoords.y + offsetY
        local spawnZ = playerCoords.z + 1.0 -- Slightly above ground

        -- Ensure the ground exists at the spawn location
        local foundGround, groundZ = GetGroundZFor_3dCoord(spawnX, spawnY, spawnZ, false)
        if foundGround then
            spawnZ = groundZ
        end

        -- Create the ped
        local ped = CreatePed(4, GetHashKey(pedModel), spawnX, spawnY, spawnZ, math.random(0, 360), true, false)

        -- Set ped to wander
        TaskWanderStandard(ped, 10.0, 10)

        -- Make the ped persistent
        SetEntityAsMissionEntity(ped, true, true)

        -- Clean up the model from memory
        SetModelAsNoLongerNeeded(pedModel)
    end

    TriggerEvent('chat:addMessage', {
        color = {0, 255, 0},
        multiline = true,
        args = {"Success", pedCount .. " peds spawned within a radius of " .. spawnRadius .. " units."}
    })
end, false)
