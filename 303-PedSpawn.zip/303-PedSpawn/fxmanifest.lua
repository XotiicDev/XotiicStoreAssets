fx_version 'cerulean'
game 'gta5'

author 'The303Studios'
description 'A script to spawn peds'
version '1.0.0'
lua54 'yes'

client_scripts {
    'client.lua'
}

shared_scripts {
    'config.lua'
}

escrow_ignore (
    'config.lua'
)