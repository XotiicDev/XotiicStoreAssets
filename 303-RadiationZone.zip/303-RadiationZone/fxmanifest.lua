fx_version 'cerulean'
game 'gta5'
version '1.10.1'
lua54 'yes'

author 'TThe303Studios'
description 'Radiation Zone Effect'
version '1.0.0'

shared_script {
    'config.lua'
}

client_script {
    'client.lua',
}
