-- Main loop for radiation effects
Citizen.CreateThread(function()
    local isDrunk = false -- Flag to track drunk effect
    while true do
        Citizen.Wait(0) -- Run the loop constantly, but we control the interval inside the logic

        local playerPed = PlayerPedId()
        local playerPos = GetEntityCoords(playerPed)

        local insideZone = false -- Track if the player is inside any zone
        local closestZone = nil -- Track the closest zone (optional)

        -- Check all radiation zones
        for _, zone in ipairs(Config.RadiationZones) do
            local distance = Vdist(playerPos.x, playerPos.y, playerPos.z, zone.coords.x, zone.coords.y, zone.coords.z)

            -- If inside a zone, apply the effects
            if distance <= zone.radius then
                insideZone = true
                closestZone = zone
                break -- Exit the loop as the player is inside a zone
            end
        end

        if insideZone and closestZone then
            -- Apply drunk effect if not already active
            if not isDrunk then
                isDrunk = true
                SetTimecycleModifier(Config.RadiationEffect.timecycle) -- Apply visual drunk effect
                ShakeGameplayCam(Config.RadiationEffect.shakeType, Config.RadiationEffect.shakeIntensity) -- Apply camera shake
            end

            -- Continuously loop until player exits the radiation zone
            while insideZone do
                Citizen.Wait(closestZone.damageInterval) -- Wait for the configured interval

                -- Apply damage every time interval
                local playerHealth = GetEntityHealth(playerPed)
                if playerHealth > 0 then
                    playerHealth = playerHealth - closestZone.damageAmount
                    SetEntityHealth(playerPed, playerHealth)
                end

                -- Recalculate distance to check if still in the closest zone
                playerPos = GetEntityCoords(playerPed)
                local distance = Vdist(playerPos.x, playerPos.y, playerPos.z, closestZone.coords.x, closestZone.coords.y, closestZone.coords.z)

                if distance > closestZone.radius then
                    insideZone = false -- Exit the loop
                end
            end
        else
            -- Remove drunk effect when leaving the zone
            if isDrunk then
                isDrunk = false
                ClearTimecycleModifier() -- Remove visual drunk effect
                StopGameplayCamShaking(true) -- Stop camera shake
            end
        end
    end
end)
