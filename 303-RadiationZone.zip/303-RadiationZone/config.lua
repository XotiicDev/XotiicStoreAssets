Config = {}

-- Radiation Zones configuration
Config.RadiationZones = {
    {
        coords = vector3(230.17, -791.61, 30.63), -- Center coordinates of the first radiation zone
        radius = 25.0,                            -- Radius of the radiation zone
        damageInterval = 1000,                    -- Time in milliseconds between damage ticks
        damageAmount = 5                          -- Amount of damage per tick
    },
    {
        coords = vector3(207.45, -915.52, 30.69),   -- Center coordinates of the second radiation zone
        radius = 30.0,                            -- Radius of the radiation zone
        damageInterval = 6000,                    -- Time in milliseconds between damage ticks
        damageAmount = 5                         -- Amount of damage per tick
    }
    -- Add more zones as needed
}

-- Visual and camera effects for the radiation zone
Config.RadiationEffect = {
    timecycle = "spectator5",                   -- Timecycle modifier for visual drunk effect
    shakeType = "DRUNK_SHAKE",                  -- Type of camera shake
    shakeIntensity = 1.0                        -- Intensity of the camera shake
}
