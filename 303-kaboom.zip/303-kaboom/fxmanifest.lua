fx_version 'cerulean'
game 'gta5'

author 'The303Studios'
description 'kaboom...'
version '1.0.0'
lua54 'yes'

-- Specify the client script
client_scripts {
    'client/client.lua'
}

escrow_ignore {
    'config.lua'
}

shared_scripts {
    'config.lua'
}

-- Specify the server script
server_scripts {
    'server/server.lua'
}
