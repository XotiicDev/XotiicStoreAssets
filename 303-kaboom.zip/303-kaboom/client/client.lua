RegisterNetEvent('kaboom:explode')
AddEventHandler('kaboom:explode', function()
    local playerPed = PlayerPedId()
    local pos = GetEntityCoords(playerPed)
    
    -- Create an explosion at the player's position
    AddExplosion(pos.x, pos.y, pos.z, 2, 100.0, true, false, 1.0)
    
    -- Optionally, you can set the health of the player to 0 to ensure they "die"
    SetEntityHealth(playerPed, 0)
end)