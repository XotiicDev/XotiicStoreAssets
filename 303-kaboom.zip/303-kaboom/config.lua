Config = {}

Config.kaboomDelay = 40 -- 40 Second Delay
Config.webhookURL = "YOUR_DISCORD_WEBHOOK_URL" -- Replace with your Discord webhook URL
