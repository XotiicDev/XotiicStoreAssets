local cooldowns = {}

-- Function to send a log to Discord
local function sendToDiscord(playerId, playerName)
    local webhook = Config.webhookURL
    if not webhook or webhook == "" then
        print("Discord webhook URL is not configured.")
        return
    end

    -- Prepare the embed message
    local embed = {
        {
            ["title"] = "Kaboom Command Used",
            ["description"] = "Player used Kaboom!",
            ["color"] = 16711680, -- Red color
            ["fields"] = {
                { ["name"] = "Player ID", ["value"] = tostring(playerId), ["inline"] = true },
                { ["name"] = "Player Name", ["value"] = playerName, ["inline"] = true },
            }
        }
    }

    -- Prepare the payload
    local payload = {
        username = "Kaboom Logger",
        embeds = embed
    }

    -- Send the HTTP POST request
    PerformHttpRequest(webhook, function(err, text, headers) end, "POST", json.encode(payload), { ["Content-Type"] = "application/json" })
end

-- Kaboom command
RegisterCommand('kaboom', function(source, args, rawCommand)
    local currentTime = os.time()

    -- Check if the player is on cooldown
    if cooldowns[source] and (currentTime - cooldowns[source] < Config.kaboomDelay) then
        -- Notify the player that they must wait
        TriggerClientEvent('chat:addMessage', source, {
            args = { 'System', 'You must wait ' .. (Config.kaboomDelay - (currentTime - cooldowns[source])) .. ' seconds before kabooming again.' }
        })
        return
    end

    -- Trigger the explosion on the client side
    TriggerClientEvent('kaboom:explode', source)

    -- Log to Discord
    local playerName = GetPlayerName(source)
    sendToDiscord(source, playerName)

    -- Set the cooldown time
    cooldowns[source] = currentTime
end, false)
