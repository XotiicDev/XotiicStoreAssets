local json = require("json") -- Ensure you have a JSON library installed for Lua
local cooldownsFile = "commendation_cooldowns.json" -- File to save cooldown data
local commendationCooldowns = {} -- Table to hold cooldown data in memory

-- Load existing cooldown data from file
local function loadCooldowns()
    local file = io.open(cooldownsFile, "r")
    if file then
        local content = file:read("*a")
        commendationCooldowns = json.decode(content) or {}
        file:close()
    else
        commendationCooldowns = {}
    end
end

-- Save cooldown data to file
local function saveCooldowns()
    local file = io.open(cooldownsFile, "w")
    if file then
        file:write(json.encode(commendationCooldowns))
        file:close()
    else
        print("^1ERROR: Unable to save cooldown data to file!^0")
    end
end

-- Function to get Discord ID of a player
local function getDiscordID(source)
    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        if identifier:sub(1, 8) == "discord:" then
            return identifier:sub(9) -- Extract the Discord ID
        end
    end
    return nil
end

-- Function to send a Discord embed message
function sendToDiscord(title, fields, color)
    if not Config.WebhookURL or Config.WebhookURL == "WEBHOOK_URL" then
        print("^1ERROR: Webhook URL is missing in config.lua^0")
        return
    end

    local embed = {
        {
            ["title"] = title,
            ["fields"] = fields,
            ["color"] = color,
            ["footer"] = {
                ["text"] = os.date("%Y-%m-%d %H:%M:%S"), -- Adds date and time to the footer
            },
        }
    }

    PerformHttpRequest(Config.WebhookURL, function(err, text, headers) end, 'POST', json.encode({ embeds = embed }), { ['Content-Type'] = 'application/json' })
end

-- Register /commend command
RegisterCommand("commend", function(source, args, rawCommand)
    local discordID = getDiscordID(source)
    if not discordID then
        TriggerClientEvent("chat:addMessage", source, { args = { "^1ERROR", "Unable to retrieve your Discord ID." } })
        return
    end

    local commenderName = GetPlayerName(source)
    local commendedID = tonumber(args[1])
    local reason = table.concat(args, " ", 2)

    if not commendedID or not reason or reason == "" then
        TriggerClientEvent("chat:addMessage", source, { args = { "^1ERROR", "Usage: /commend {playerID} {reason}" } })
        return
    end

    local commendedName = GetPlayerName(commendedID)
    if not commendedName then
        TriggerClientEvent("chat:addMessage", source, { args = { "^1ERROR", "Player ID not found." } })
        return
    end

    -- Check cooldown
    local currentTime = os.time()
    local lastCommendation = commendationCooldowns[discordID]
    local cooldownPeriod = Config.CooldownPeriod
    if lastCommendation and (currentTime - lastCommendation < cooldownPeriod) then
        local timeLeft = cooldownPeriod - (currentTime - lastCommendation)
        local daysLeft = math.floor(timeLeft / (24 * 60 * 60))
        local hoursLeft = math.floor((timeLeft % (24 * 60 * 60)) / (60 * 60))
        local minutesLeft = math.floor((timeLeft % (60 * 60)) / 60)
        TriggerClientEvent("chat:addMessage", source, { args = { "^1ERROR", "You commended too soon. Time left: " .. daysLeft .. " days, " .. hoursLeft .. " hours," .. minutesLeft .. " minutes."} })
        return
    end

    -- Record the commendation
    commendationCooldowns[discordID] = currentTime
    saveCooldowns() -- Save to file

    -- Build embed fields
    local fields = {
        { ["name"] = "Commended Player", ["value"] = commendedName .. " (ID: " .. commendedID .. ")", ["inline"] = true },
        { ["name"] = "Commender", ["value"] = commenderName .. " (Discord ID: " .. discordID .. ")", ["inline"] = true },
        { ["name"] = "Reason", ["value"] = reason, ["inline"] = false },
    }

    -- Send embed to Discord
    sendToDiscord("New Commendation", fields, 3066993) -- Green color for the embed

    -- Notify the commender
    TriggerClientEvent("chat:addMessage", source, { args = { "^2SUCCESS", "Commendation sent for " .. commendedName .. "!" } })
end, false)

-- Load cooldown data on script start
loadCooldowns()
