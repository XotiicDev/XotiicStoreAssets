fx_version 'cerulean'
game 'gta5'

author 'The303Studios'
description 'Commendation system for FiveM with Discord integration'
version '1.1.4'

lua54 'yes'

server_scripts {        
    'server/server.lua'  
}

escrow_ignore {
    'shared/config.lua'
}

shared_scripts {
    'shared/config.lua',
    'json.lua'
}
