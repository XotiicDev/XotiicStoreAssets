local json = {}

function json.encode(obj)
    local function serialize(tbl)
        local result = {}

        for key, value in pairs(tbl) do
            local formattedKey = type(key) == "string" and '"' .. key .. '"' or key

            if type(value) == "table" then
                value = serialize(value)
            elseif type(value) == "string" then
                value = '"' .. value .. '"'
            end

            table.insert(result, formattedKey .. ":" .. tostring(value))
        end

        return "{" .. table.concat(result, ",") .. "}"
    end

    return serialize(obj)
end

function json.decode(str)
    local function parse()
        return load("return " .. str, nil, "t", {})()
    end

    local success, result = pcall(parse)

    if success then
        return result
    else
        print("^1ERROR: Failed to decode JSON string. Make sure the JSON is valid.^0")
        return nil
    end
end

return json
