Config = {}

-- Discord webhook URL
Config.WebhookURL = "https://discord.com/api/webhooks/1312549866429218976/jQGulPbe7JgFJ03KUwm6n5L7pBE8VqtWd10vtk-KrOivRsi1Jd28PtIqkC-0yuRDhcPn"

-- Cooldown period for commendations (in seconds)
-- Default is 7 days: 7 * 24 * 60 * 60 = 604800 seconds
Config.CooldownPeriod = 7 * 24 * 60 * 60
