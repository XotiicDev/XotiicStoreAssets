local vestEnabled = false

-- Event to enable the vest
RegisterNetEvent('303Studios:Enable')
AddEventHandler('303Studios:Enable', function()
    vestEnabled = true
end)

-- Event to disable the vest
RegisterNetEvent('303Studios:Disable')
AddEventHandler('303Studios:Disable', function()
    vestEnabled = false
end)

-- Listen for the custom detonation key press
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0) -- Always check
        if vestEnabled then
            -- Check if the custom key is pressed
            if IsControlJustPressed(1, Config.DetonateKey) then
                local playerPed = PlayerPedId()
                local coords = GetEntityCoords(playerPed)
                local playerId = GetPlayerServerId(PlayerId())
                local playerName = GetPlayerName(PlayerId())

                -- Create an explosion at the player's location
                AddExplosion(coords.x, coords.y, coords.z, Config.ExplosionType, Config.ExplosionRadius, true, false, 1.0)

                -- Kill the player
                SetEntityHealth(playerPed, 0)
                
                -- Disable the vest after detonation
                vestEnabled = false
                if Config.EnableMessages then
                    TriggerEvent('chat:addMessage', {
                        args = {"^1You have detonated your vest!"}
                    })
                end

                -- Log detonation to Discord
                TriggerServerEvent('303Studios:LogDetonation', playerName, playerId)
            end
        end
    end
end)
