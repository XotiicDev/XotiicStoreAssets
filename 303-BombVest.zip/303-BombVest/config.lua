Config = {}

-- Explosion type (see FiveM explosion types: https://docs.fivem.net/docs/game-references/explosions/)
Config.ExplosionType = 29  -- Example: 29 is a grenade-like explosion

-- Explosion damage radius (higher values = larger explosions)
Config.ExplosionRadius = 5.0

-- Toggle suicide vest messages
Config.EnableMessages = true

-- Custom keybind for detonation
Config.DetonateKey = 74 -- Default: H key (https://docs.fivem.net/docs/game-references/controls/)

-- Discord Webhook URL for logging events
Config.DiscordWebhook = " "
--Embed Colors Are As Followed
--Green (3066993): Vest enabled.
--Red (15105570): Vest disabled.
--Purple (15158332): Vest detonated.