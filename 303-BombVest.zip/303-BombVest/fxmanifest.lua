fx_version 'cerulean'
game 'gta5'

author 'The303Studios'
description 'A suicide vest script with /suvest command'
version '1.0.0'

lua54 'yes'

escrow_ignore 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
shared_script 'config.lua'
