local vestEnabled = {}

-- Function to send logs to Discord
local function sendToDiscord(title, message, color)
    PerformHttpRequest(Config.DiscordWebhook, function(err, text, headers) 
        -- Log errors to the console if necessary
    end, "POST", json.encode({
        embeds = {{
            title = title,
            description = message,
            color = color
        }}
    }), { ["Content-Type"] = "application/json" })
end

-- Register the /suvest command
RegisterCommand('suvest', function(source, args, rawCommand)
    local playerId = source
    local playerName = GetPlayerName(playerId)

    -- Toggle the vest for the player
    vestEnabled[playerId] = not vestEnabled[playerId]
    
    if vestEnabled[playerId] then
        TriggerClientEvent('303Studios:Enable', playerId)
        if Config.EnableMessages then
            TriggerClientEvent('chat:addMessage', playerId, {
                args = {"^2Suicide vest ^0enabled! Press ^1H ^0(or your configured key) to detonate."}
            })
        end

        -- Log to Discord
        sendToDiscord("New Suicide Vest Activation", ("User: **%s** [ID: %d] has enabled a suicide vest."):format(playerName, playerId), 3066993)
    else
        TriggerClientEvent('303Studios:Disable', playerId)
        if Config.EnableMessages then
            TriggerClientEvent('chat:addMessage', playerId, {
                args = {"^1Suicide vest ^0disabled."}
            })
        end

        -- Log to Discord
        sendToDiscord("Suicide Vest Disabled", ("User: **%s** [ID: %d] has disabled their suicide vest."):format(playerName, playerId), 15105570)
    end
end, false)

-- Handle player disconnects to clean up the vest state
AddEventHandler('playerDropped', function(reason)
    local playerId = source
    vestEnabled[playerId] = nil
end)

Citizen.CreateThread(function()
    Citizen.Wait(1000) -- Wait for 1 second after server starts

    -- Check if the Webhook URL is missing in the config
    if Config.WebhookURL == "" then
        print('^1[ERROR]^0 Missing Webhook URL in 303-BombVest Config.lua!')
    else
        print('^2303-BombVest^0 is live and running!')
    end

    print([[
 DDDD   EEEEE  V   V  W   W  OOO  RRRR   L      DDDD
 D   D  E      V   V  W   W O   O R   R  L      D   D
 D   D  EEEE   V   V  W W W O   O RRRR   L      D   D
 D   D  E      V   V  WW WW O   O R  R   L      D   D
 DDDD   EEEEE   VVV   W   W  OOO  R   R  LLLLL  DDDD
    ]])
end)


