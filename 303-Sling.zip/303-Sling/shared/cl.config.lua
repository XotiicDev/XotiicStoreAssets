Config = {}

-- Excluded weapons (handguns) ["WEAPON SPAWNCODE"] = true,  or false 
Config.ExcludedWeapons = {
    ["weapon_pistol"] = true,
    ["weapon_revolver"] = true,
    ["weapon_snspistol"] = true,
    ["weapon_combatpistol"] = true,
    ["weapon_appistol"] = true,
    ["weapon_ceramicpistol"] = true,
    ["weapon_heavypistol"] = true,
    ["weapon_doubleaction"] = true,
    ["weapon_vintagepistol"] = true,
    ["weapon_marksmanpistol"] = true,
    ["weapon_navyrevolver"] = true
}

-- Sling props for weapons ["WEAPON SPAWNCODE"] = "MODEL NAME",...
Config.SlingProps = {
    ["weapon_carbinerifle"] = "w_ar_carbinerifle",
    ["weapon_assaultrifle"] = "w_ar_assaultrifle",
    ["weapon_specialcarbine"] = "w_ar_specialcarbine",
    ["weapon_bullpuprifle"] = "w_ar_bullpuprifle",
    ["weapon_compactrifle"] = "w_ar_compactrifle",
    ["weapon_pumpshotgun"] = "w_sg_pumpshotgun",
    ["weapon_sawnoffshotgun"] = "w_sg_sawnoff",
    ["weapon_assaultshotgun"] = "w_sg_assaultshotgun",
    ["weapon_bullpupshotgun"] = "w_sg_bullpupshotgun",
    ["weapon_heavyshotgun"] = "w_sg_heavyshotgun",
    ["weapon_combatshotgun"] = "w_sg_combatshotgun",
    ["weapon_mg"] = "w_mg_mg",
    ["weapon_combatmg"] = "w_mg_combatmg",
    ["weapon_gusenberg"] = "w_sb_gusenberg",
    ["weapon_minigun"] = "w_mg_minigun",
    ["weapon_rpg"] = "w_lr_rpg",
    ["weapon_grenadelauncher"] = "w_lr_grenadelauncher",
    ["weapon_hominglauncher"] = "w_lr_hominglauncher",
    ["weapon_firework"] = "w_lr_firework",
    ["weapon_marksmanrifle"] = "w_sr_marksmanrifle",
    ["weapon_sniperrifle"] = "w_sr_sniperrifle",
    ["weapon_heavysniper"] = "w_sr_heavysniper",
    ["weapon_heavysniper_mk2"] = "w_sr_heavysnipermk2",
    ["weapon_musket"] = "w_ar_musket"
    -- Add more weapons as necessary
}

-- Custom weapons can be added here ["WEAPON SPAWNCODE"] = "MODEL NAME",...
Config.CustomWeapons = {
    ["weapon_customrifle"] = "w_ar_customrifle",
    ["weapon_customshotgun"] = "w_sg_customshotgun"
}
