local EXCLUDED_WEAPONS = Config.ExcludedWeapons
local slingProps = Config.SlingProps

local slungWeapons = {}
local slungWeaponAmmo = {} -- To store the ammo count for slung weapons

-- Register /sling command
RegisterCommand("sling", function()
    local playerPed = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(playerPed)
    local weaponName = GetWeaponNameFromHash(weaponHash)

    if not weaponName then
        TriggerEvent("chat:addMessage", { args = { "System", "You are not holding a valid weapon." } })
        return
    end

    if EXCLUDED_WEAPONS[weaponName] then
        TriggerEvent("chat:addMessage", { args = { "System", "You cannot sling handguns." } })
        return
    end

    if slungWeapons[weaponName] then
        RemoveSlungWeapon(playerPed, weaponName)
        slungWeapons[weaponName] = nil
        TriggerEvent("chat:addMessage", { args = { "System", "Weapon unslung." } })
        SetCanUseWeapon(playerPed, weaponHash, true, slungWeaponAmmo[weaponName])
        slungWeaponAmmo[weaponName] = nil
    else
        local currentAmmo = GetAmmoInPedWeapon(playerPed, weaponHash)
        slungWeaponAmmo[weaponName] = currentAmmo
        SlingWeapon(playerPed, weaponName)
        slungWeapons[weaponName] = true
        TriggerEvent("chat:addMessage", { args = { "System", "Weapon slung." } })
        SetCanUseWeapon(playerPed, weaponHash, false)
    end
end, false)

-- Register /unsling command
RegisterCommand("unsling", function()
    local playerPed = PlayerPedId()

    -- Check if the player has any slung weapon
    local slungWeaponName = nil
    for weaponName, isSlung in pairs(slungWeapons) do
        if isSlung then
            slungWeaponName = weaponName
            break
        end
    end

    if not slungWeaponName then
        TriggerEvent("chat:addMessage", { args = { "System", "No slung weapon to unsling." } })
        return
    end

    -- Unsling the weapon
    RemoveSlungWeapon(playerPed, slungWeaponName)
    slungWeapons[slungWeaponName] = nil
    local weaponHash = GetHashKey(slungWeaponName)
    TriggerEvent("chat:addMessage", { args = { "System", "Weapon unslung and equipped." } })
    SetCanUseWeapon(playerPed, weaponHash, true, slungWeaponAmmo[slungWeaponName])
    SetCurrentPedWeapon(playerPed, weaponHash, true) -- Equip the weapon immediately
    slungWeaponAmmo[slungWeaponName] = nil
end, false)

-- Function to sling the weapon
function SlingWeapon(playerPed, weaponName)
    local slingModel = slingProps[weaponName]
    if not slingModel then
        TriggerEvent("chat:addMessage", { args = { "System", "This weapon does not have a sling model configured." } })
        return
    end

    local playerCoords = GetEntityCoords(playerPed)
    RequestModel(slingModel)
    while not HasModelLoaded(slingModel) do
        Wait(10)
    end

    local slingObject = CreateObject(GetHashKey(slingModel), playerCoords.x, playerCoords.y, playerCoords.z, true, true, true)
    AttachEntityToEntity(slingObject, playerPed, GetPedBoneIndex(playerPed, 24816), 0.1, -0.15, 0.05, 0, 170.0, 0, false, false, false, false, 2, true)
    SetModelAsNoLongerNeeded(slingModel)
    TriggerEvent("chat:addMessage", { args = { "System", "Weapon slung successfully." } })
end

-- Function to remove the slung weapon
function RemoveSlungWeapon(playerPed, weaponName)
    for _, object in ipairs(GetGamePool("CObject")) do
        if IsEntityAttachedToEntity(object, playerPed) and GetEntityModel(object) == GetHashKey(slingProps[weaponName]) then
            DeleteObject(object)
            break
        end
    end
end

-- Function to enable or disable weapon usage
function SetCanUseWeapon(playerPed, weaponHash, canUse, ammo)
    if not canUse then
        SetPedAmmo(playerPed, weaponHash, 0)
        RemoveWeaponFromPed(playerPed, weaponHash)
    else
        GiveWeaponToPed(playerPed, weaponHash, 0, false, false)
        if ammo then
            SetPedAmmo(playerPed, weaponHash, ammo)
        end
    end
end

-- Function to get weapon name from its hash
function GetWeaponNameFromHash(weaponHash)
    for weaponName, slingModel in pairs(slingProps) do
        if GetHashKey(weaponName) == weaponHash then
            return weaponName
        end
    end

    -- Check for custom weapons added during runtime
    for customWeapon, customModel in pairs(Config.CustomWeapons) do
        if GetHashKey(customWeapon) == weaponHash then
            slingProps[customWeapon] = customModel -- Add to slingProps for easy lookup next time
            return customWeapon
        end
    end

    return nil
end
