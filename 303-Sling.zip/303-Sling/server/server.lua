Citizen.CreateThread(function()
    Citizen.Wait(1000) -- Wait for 1 second after server starts
    if _G ~= nil and type(_G) == "table" then
        print('^2303-SlingScript^0 is live and running!')
    else
        print('^1ERROR: ^0_G is a null pointer reference!')
    end
end)

Citizen.CreateThread(function()
    Citizen.Wait(1000) -- Wait for 1 second after server starts
    if pcall(function() print([[
     _____  ____  _____    _____  __     ____ _   __ ______
    |__  / / __ \|__  /   / ___/ / /    /  _// | / // ____/
     /_ < / / / / /_ <    \__ \ / /     / / /  |/ // / __  
   ___/ // /_/ /___/ /   ___/ // /___ _/ / / /|  // /_/ /  
  /____/ \____//____/   /____//_____//___//_/ |_/ \____/     
    ]]) end) then
    else
        print('^1ERROR: ^0Could not print the ASCII art!')
    end
end)
