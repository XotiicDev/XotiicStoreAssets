fx_version 'cerulean'
game 'gta5'
author 'The303Studios'
description 'FiveM Weapon Sling Script'
lua54 'yes'


-- Declare the client and server scripts
client_scripts {
    'client/client.lua'   -- Client script
}

server_scripts {
    'server/server.lua'   -- Server script
}

escrow_ignore {
    'shared/cl.config.lua'  -- Ignore the config file
}

-- Load the configuration file first
shared_script 'shared/cl.config.lua'  -- This loads the config file for both client and server
