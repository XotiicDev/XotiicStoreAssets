fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'The303Studios'
description 'Check your money stats using qb notify function'
version '1.1.5'

client_scripts {
    'client.lua',
}

server_scripts {
    'server.lua',
}

