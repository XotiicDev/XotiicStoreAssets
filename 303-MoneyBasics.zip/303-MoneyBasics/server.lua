local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('cashAndBankInfo:getCash')
AddEventHandler('cashAndBankInfo:getCash', function()
    local player = source
    local cash = QBCore.Functions.GetPlayer(player).PlayerData.money['cash']
    TriggerClientEvent('cashAndBankInfo:sendCash', player, cash)
end)

RegisterServerEvent('cashAndBankInfo:getBank')
AddEventHandler('cashAndBankInfo:getBank', function()
    local player = source
    local bank = QBCore.Functions.GetPlayer(player).PlayerData.money['bank']
    TriggerClientEvent('cashAndBankInfo:sendBank', player, bank)
end)
