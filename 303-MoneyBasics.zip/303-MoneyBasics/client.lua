local QBCore = exports['qb-core']:GetCoreObject()  -- Correctly initialize QBCore

-- Command to check cash balance
RegisterCommand("cash", function()
    TriggerServerEvent('cashAndBankInfo:getCash')
end, false)

-- Command to check bank balance
RegisterCommand("bank", function()
    TriggerServerEvent('cashAndBankInfo:getBank')
end, false)

-- Handle receiving cash balance and notify the player
RegisterNetEvent('cashAndBankInfo:sendCash')
AddEventHandler('cashAndBankInfo:sendCash', function(cash)
    QBCore.Functions.Notify("Cash Balance: $" .. cash, "success")  -- Display cash balance notification
end)

-- Handle receiving bank balance and notify the player
RegisterNetEvent('cashAndBankInfo:sendBank')
AddEventHandler('cashAndBankInfo:sendBank', function(bank)
    QBCore.Functions.Notify("Bank Balance: $" .. bank, "success")  -- Display bank balance notification
end)
