local QBCore = exports['qb-core']:GetCoreObject()

-- Function to send messages to Discord via a Webhook
function sendToDiscord(message)
    local webhookURL = Config.WebhookURL  -- Use the Webhook URL from config.lua

    local embed = {
        {
            ["color"] = 3447003,  -- Embed color (default: blue)
            ["title"] = "303 Commands",  -- Title of the embed
            ["description"] = message,  -- Message content
            ["footer"] = {
                ["text"] = "Script Created By The303Studios"
            }
        }
    }

    PerformHttpRequest(webhookURL, function(err, text, headers) end, 'POST', json.encode({embeds = embed}), {['Content-Type'] = 'application/json'})
end

RegisterCommand('do', function(source, args)
    local message = table.concat(args, ' ')
    if message ~= '' then
        local playerName = QBCore.Functions.GetPlayer(source).PlayerData.charinfo.firstname .. ' ' .. QBCore.Functions.GetPlayer(source).PlayerData.charinfo.lastname
        
        -- Send message to Discord
        local logMessage = "DO Command used by " .. playerName .. ": " .. message
        sendToDiscord(logMessage)

        -- Send message to chat
        TriggerClientEvent('chat:addMessage', -1, {
            args = { playerName, message },
            color = Config.Colors.doMessage
        })
    end
end, false)

RegisterCommand('medical', function(source, args)
    local message = table.concat(args, ' ')
    if message ~= '' then
        local playerName = QBCore.Functions.GetPlayer(source).PlayerData.charinfo.firstname .. ' ' .. QBCore.Functions.GetPlayer(source).PlayerData.charinfo.lastname
        
        -- Send message to Discord
        local logMessage = "Medical Command used by " .. playerName .. ": " .. message
        sendToDiscord(logMessage)

        -- Send message to chat
        TriggerClientEvent('chat:addMessage', -1, {
            args = { playerName .. ' [Medical]', message },
            color = Config.Colors.medicalMessage
        })
    end
end, false)

RegisterCommand('ad', function(source, args)
    local message = table.concat(args, ' ')
    if message ~= '' then
        -- Send message to Discord
        local logMessage = "Advert Command used: " .. message
        sendToDiscord(logMessage)

        -- Send message to chat
        TriggerClientEvent('chat:addMessage', -1, {
            args = { '[ADVERT]', message },
            color = Config.Colors.advertMessage
        })
    end
end, false)

-- Command for LEO messages
RegisterCommand('leo', function(source, args)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player and Player.PlayerData.job.name == "police" then
        local message = table.concat(args, ' ')
        if message ~= '' then
            local playerName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
            
            -- Send message to Discord
            local logMessage = "LEO Command used by " .. playerName .. ": " .. message
            sendToDiscord(logMessage)

            -- Send message to chat
            TriggerClientEvent('chat:addMessage', -1, {
                args = { playerName .. ' [LEO]', message },
                color = Config.Colors.leoMessage
            })
        end
    end
end, false)

-- Command for RTO messages
RegisterCommand('rto', function(source, args)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player and Player.PlayerData.job.name == "police" then
        local message = table.concat(args, ' ')
        if message ~= '' then
            local playerName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
            
            -- Send message to Discord
            local logMessage = "RTO Command used by " .. playerName .. ": " .. message
            sendToDiscord(logMessage)

            -- Send message to chat
            TriggerClientEvent('chat:addMessage', -1, {
                args = { playerName .. ' [RTO]', message },
                color = Config.Colors.rtoMessage
            })
        end
    end
end, false)

-- Function to check if player is police
local function isPolice(source)
    local Player = QBCore.Functions.GetPlayer(source)
    return Player and Player.PlayerData.job.name == "police"
end

-- Updated message sending to only police players
local function sendToPolice(messageArgs, color)
    for _, playerId in ipairs(GetPlayers()) do
        if isPolice(playerId) then
            TriggerClientEvent('chat:addMessage', playerId, {
                args = messageArgs,
                color = color
            })
        end
    end
end

RegisterCommand('news', function(source, args)
    local message = table.concat(args, ' ')
    if message ~= '' then
        -- Send message to Discord
        local logMessage = "News Command used: " .. message
        sendToDiscord(logMessage)

        -- Send message to chat
        TriggerClientEvent('chat:addMessage', -1, {
            args = { '[WEAZEL NEWS]', message },
            color = Config.Colors.newsMessage
        })
    end
end, false)

local anonNames = {}

-- Command to send dark web messages
RegisterCommand("darkweb", function(source, args)
    local player = source
    local message = table.concat(args, " ")

    -- Check if the player has the police job
    local playerJob = QBCore.Functions.GetPlayer(player).PlayerData.job.name
    if playerJob == "police" then
        return -- Police cannot see this message
    end

    -- Get or generate anonName
    if not anonNames[player] then
        local randomNumber = math.random(1000, 9999)
        anonNames[player] = "Anon" .. randomNumber
    end

    local anonName = anonNames[player]

    -- Log Dark Web message to Discord
    local logMessage = "Dark Web message from " .. anonName .. ": " .. message
    sendToDiscord(logMessage)

    -- Send the dark web message to chat
    TriggerClientEvent("chat:addMessage", -1, {
        args = { anonName .. " (Dark Web):", message },
        color = Config.Colors.darkwebMessage
    })
end, false)

-- Command to change anonName
RegisterCommand("VPN", function(source)
    local randomNumber = math.random(1000, 9999)
    anonNames[source] = "Anon" .. randomNumber

    -- Send the new anonName to Discord
    local logMessage = "Player " .. source .. " changed VPN to " .. anonNames[source]
    sendToDiscord(logMessage)

    -- Send the new anonName to the player
    TriggerClientEvent("chat:addMessage", source, {
        args = { "You are now known as:", anonNames[source] },
        color = Config.Colors.vpnMessage
    })
end, false)
