fx_version 'cerulean'
game 'gta5'
author 'The303Studios'
lua54 'on'
version '1.1.14'

escrow_ignore {
    'config.lua'
}

server_scripts {
    'server.lua'
}
 shared_scripts {
    'config.lua'
 }
