Config = {}

Config.WebhookURL = "YOUR_DISCORD_WEBHOOK_URL"  -- Replace with your actual Discord webhook URL

Config.Colors = {
    doMessage = { 0, 255, 0 },      -- Green
    medicalMessage = { 255, 0, 0 },   -- Red
    darkwebMessage = { 128, 0, 128 }, -- Purple
    vpnMessage = { 0, 0, 255 },         -- Blue
    advertMessage = { 255, 165, 0 },        -- Orange (for advertisements)
    newsMessage = { 255, 0, 0 },       -- Red
    leoMessage = { 0, 0, 255 }, -- Blue for Police
    rtoMessage = { 255, 0, 0 }, -- Red For Major Alert
}

