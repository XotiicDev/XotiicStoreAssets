fx_version 'cerulean'
game 'gta5'

author 'The303Studios'
description 'Script to disable reticle for all weapons except snipers'
version '1.0.0'
lua54 'yes'

client_script 'client.lua' -- Run the client script
