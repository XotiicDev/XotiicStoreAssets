-- Script to disable reticle for all weapons except snipers
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0) -- Run every tick
        local ped = PlayerPedId() -- Get the player's Ped
        local weaponHash = GetSelectedPedWeapon(ped) -- Get the current weapon
        
        -- List of sniper rifles (you can expand if necessary)
        local sniperWeapons = {
            `WEAPON_SNIPERRIFLE`,
            `WEAPON_HEAVYSNIPER`,
            `WEAPON_HEAVYSNIPER_MK2`,
            `WEAPON_MARKSMANRIFLE`,
            `WEAPON_MARKSMANRIFLE_MK2`
        }

        local isSniper = false

        -- Check if the current weapon is a sniper
        for _, sniper in ipairs(sniperWeapons) do
            if weaponHash == sniper then
                isSniper = true
                break
            end
        end

        -- Disable reticle if not a sniper
        if not isSniper then
            HideHudComponentThisFrame(14) -- Component 14 is the weapon reticle
        end
    end
end)
